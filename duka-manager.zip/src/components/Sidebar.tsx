'use client'
import Link from 'next/link'
import { usePathname } from 'next/navigation'

const navItems = [
  { section: 'Main' },
  { href: '/', label: 'Dashboard', icon: '📊' },
  { href: '/pos', label: 'New Sale', icon: '🧾' },
  { section: 'Inventory' },
  { href: '/stock', label: 'Stock', icon: '📦' },
  { href: '/stock/add', label: 'Add Stock', icon: '➕' },
  { section: 'Finance' },
  { href: '/sales', label: 'Sales History', icon: '💰' },
  { href: '/credit', label: 'Credit / Debtors', icon: '📋' },
  { href: '/expenses', label: 'Expenses', icon: '💸' },
  { section: 'Reports' },
  { href: '/reports/daily', label: 'Daily Summary', icon: '📅' },
  { href: '/reports/monthly', label: 'Monthly Report', icon: '📈' },
]

export default function Sidebar() {
  const pathname = usePathname()

  return (
    <nav className="fixed left-0 top-0 bottom-0 w-60 bg-surface border-r border-border flex flex-col z-50 no-print">
      {/* Logo */}
      <div className="px-5 py-6 border-b border-border">
        <h1 className="font-serif text-accent text-xl tracking-tight">Duka Manager</h1>
        <p className="text-xs text-muted uppercase tracking-widest mt-1">Wholesale & Retail</p>
      </div>

      {/* Nav */}
      <div className="flex-1 overflow-y-auto py-4 px-3">
        {navItems.map((item, i) => {
          if ('section' in item) {
            return (
              <p key={i} className="text-[10px] text-muted uppercase tracking-widest px-3 pt-4 pb-1 mt-2">
                {item.section}
              </p>
            )
          }
          const active = pathname === item.href || (item.href !== '/' && pathname.startsWith(item.href))
          return (
            <Link
              key={item.href}
              href={item.href}
              className={`flex items-center gap-3 px-3 py-2.5 rounded-lg mb-0.5 text-sm font-medium transition-all
                ${active
                  ? 'bg-accent/10 text-accent'
                  : 'text-sub hover:bg-surface2 hover:text-white'
                }`}
            >
              <span className="w-5 text-center text-base">{item.icon}</span>
              {item.label}
            </Link>
          )
        })}
      </div>

      {/* Footer */}
      <div className="px-5 py-4 border-t border-border">
        <p className="text-[11px] text-muted">
          {new Date().toLocaleDateString('en-KE', { weekday: 'short', day: '2-digit', month: 'short', year: 'numeric' })}
        </p>
      </div>
    </nav>
  )
}

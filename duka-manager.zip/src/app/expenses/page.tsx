'use client'
import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { fmt, fmtDate, today } from '@/lib/utils'

const CATEGORIES = ['Stock Purchase', 'Transport', 'Employee Salary', 'Rent', 'Electricity / Water', 'Other']

export default function ExpensesPage() {
  const [expenses, setExpenses] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [showModal, setShowModal] = useState(false)
  const [editExp, setEditExp] = useState<any>(null)
  const [dateFilter, setDateFilter] = useState('')
  const [form, setForm] = useState({ category: 'Transport', description: '', amount: '', expense_date: today() })

  function load() {
    setLoading(true)
    const params = new URLSearchParams()
    if (dateFilter) params.set('date', dateFilter)
    fetch(`/api/expenses?${params}`)
      .then(r => r.json())
      .then(d => { setExpenses(d.data || []); setLoading(false) })
  }

  useEffect(() => { load() }, [dateFilter])

  function openAdd() {
    setEditExp(null)
    setForm({ category: 'Transport', description: '', amount: '', expense_date: today() })
    setShowModal(true)
  }

  function openEdit(exp: any) {
    setEditExp(exp)
    setForm({ category: exp.category, description: exp.description, amount: exp.amount, expense_date: exp.expense_date.split('T')[0] })
    setShowModal(true)
  }

  async function save() {
    if (!form.amount || !form.category) return toast.error('Category and amount required')
    try {
      const url = editExp ? `/api/expenses/${editExp.id}` : '/api/expenses'
      const method = editExp ? 'PUT' : 'POST'
      const res = await fetch(url, {
        method,
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ ...form, amount: Number(form.amount) })
      })
      if (!res.ok) throw new Error('Failed')
      toast.success(editExp ? 'Expense updated!' : 'Expense added!')
      setShowModal(false)
      load()
    } catch (e: any) { toast.error(e.message) }
  }

  async function del(id: number) {
    if (!confirm('Delete this expense?')) return
    await fetch(`/api/expenses/${id}`, { method: 'DELETE' })
    toast.success('Deleted')
    load()
  }

  const totalToday = expenses.filter(e => e.expense_date?.startsWith(today())).reduce((a, e) => a + Number(e.amount), 0)
  const totalShown = expenses.reduce((a, e) => a + Number(e.amount), 0)

  const byCategory = CATEGORIES.map(cat => ({
    cat,
    total: expenses.filter(e => e.category === cat).reduce((a, e) => a + Number(e.amount), 0)
  })).filter(x => x.total > 0)

  return (
    <div className="animate-in">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="page-title">Expenses</h1>
          <p className="page-sub">Track all business costs</p>
        </div>
        <button className="btn btn-primary" onClick={openAdd}>➕ Add Expense</button>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="stat-card red">
          <div className="stat-label">Today's Expenses</div>
          <div className="stat-value">{Number(totalToday).toLocaleString('en-KE', { minimumFractionDigits: 0 })}</div>
        </div>
        <div className="stat-card yellow">
          <div className="stat-label">Shown Total</div>
          <div className="stat-value">{Number(totalShown).toLocaleString('en-KE', { minimumFractionDigits: 0 })}</div>
        </div>
        {byCategory.slice(0, 2).map(x => (
          <div key={x.cat} className="stat-card blue">
            <div className="stat-label">{x.cat}</div>
            <div className="stat-value">{Number(x.total).toLocaleString('en-KE', { minimumFractionDigits: 0 })}</div>
          </div>
        ))}
      </div>

      {/* Filter + Table */}
      <div className="duka-card mb-4 flex gap-4 items-end">
        <div className="flex-1 max-w-xs">
          <label className="duka-label">Filter by Date</label>
          <input type="date" className="duka-input" value={dateFilter} onChange={e => setDateFilter(e.target.value)} />
        </div>
        {dateFilter && <button className="btn btn-outline" onClick={() => setDateFilter('')}>Clear</button>}
      </div>

      <div className="duka-card">
        {loading ? <div className="empty-state">Loading...</div> : expenses.length === 0 ? (
          <div className="empty-state">No expenses recorded yet</div>
        ) : (
          <table className="duka-table">
            <thead>
              <tr><th>Date</th><th>Category</th><th>Description</th><th>Amount</th><th>Actions</th></tr>
            </thead>
            <tbody>
              {expenses.map(e => (
                <tr key={e.id}>
                  <td>{fmtDate(e.expense_date)}</td>
                  <td><span className="badge badge-yellow">{e.category}</span></td>
                  <td>{e.description || <span className="text-muted">—</span>}</td>
                  <td className="mono text-red font-medium">{fmt(e.amount)}</td>
                  <td>
                    <div className="flex gap-2">
                      <button className="btn btn-outline btn-sm" onClick={() => openEdit(e)}>✏️</button>
                      <button className="btn btn-ghost btn-sm text-red" onClick={() => del(e.id)}>🗑️</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      {/* Modal */}
      {showModal && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setShowModal(false)}>
          <div className="modal" style={{ maxWidth: 480 }}>
            <h2 className="modal-title">{editExp ? 'Edit Expense' : 'Add Expense'}</h2>
            <div className="space-y-4">
              <div>
                <label className="duka-label">Category</label>
                <select className="duka-input duka-select" value={form.category} onChange={e => setForm(f => ({ ...f, category: e.target.value }))}>
                  {CATEGORIES.map(c => <option key={c}>{c}</option>)}
                </select>
              </div>
              <div>
                <label className="duka-label">Description</label>
                <input className="duka-input" placeholder="Brief description (optional)" value={form.description} onChange={e => setForm(f => ({ ...f, description: e.target.value }))} />
              </div>
              <div>
                <label className="duka-label">Amount (KES)</label>
                <input type="number" step="0.01" className="duka-input" placeholder="0.00" value={form.amount} onChange={e => setForm(f => ({ ...f, amount: e.target.value }))} />
              </div>
              <div>
                <label className="duka-label">Date</label>
                <input type="date" className="duka-input" value={form.expense_date} onChange={e => setForm(f => ({ ...f, expense_date: e.target.value }))} />
              </div>
            </div>
            <div className="flex justify-end gap-3 mt-6">
              <button className="btn btn-outline" onClick={() => setShowModal(false)}>Cancel</button>
              <button className="btn btn-primary" onClick={save}>Save</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

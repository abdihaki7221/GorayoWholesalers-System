import { NextRequest, NextResponse } from 'next/server'
import { query, queryOne } from '@/lib/db'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const date = searchParams.get('date') || new Date().toISOString().split('T')[0]

    const prev = new Date(date)
    prev.setDate(prev.getDate() - 1)
    const prevStr = prev.toISOString().split('T')[0]

    // Sales totals
    const [salesSummary] = await query(`
      SELECT
        COUNT(DISTINCT s.id)                                          AS tx_count,
        COALESCE(SUM(s.total), 0)                                    AS total_sales,
        COALESCE(SUM(s.profit), 0)                                   AS total_profit,
        COALESCE(SUM(CASE WHEN s.status='pending' THEN s.total ELSE 0 END), 0) AS pending_amount
      FROM sales s WHERE s.sale_date = $1
    `, [date])

    // Split-aware payment breakdown
    const [payBreakdown] = await query(`
      SELECT
        COALESCE(SUM(CASE WHEN sp.method='cash'   THEN sp.amount ELSE 0 END), 0) AS cash_sales,
        COALESCE(SUM(CASE WHEN sp.method='mpesa'  THEN sp.amount ELSE 0 END), 0) AS mpesa_sales,
        COALESCE(SUM(CASE WHEN sp.method='kcb'    THEN sp.amount ELSE 0 END), 0) AS kcb_sales,
        COALESCE(SUM(CASE WHEN sp.method='credit' THEN sp.amount ELSE 0 END), 0) AS credit_sales
      FROM sale_payments sp
      JOIN sales s ON s.id = sp.sale_id
      WHERE s.sale_date = $1
    `, [date])

    // Previous day cash
    const [prevCashRow] = await query(`
      SELECT COALESCE(SUM(sp.amount), 0) AS prev_cash
      FROM sale_payments sp
      JOIN sales s ON s.id = sp.sale_id
      WHERE s.sale_date = $1 AND sp.method = 'cash' AND s.status = 'paid'
    `, [prevStr])

    const [expenseSummary] = await query(`
      SELECT
        COALESCE(SUM(amount), 0)                                                AS total_expenses,
        COALESCE(SUM(CASE WHEN category='Stock Purchase' THEN amount ELSE 0 END), 0) AS stock_expenses,
        COALESCE(SUM(CASE WHEN category='Transport'      THEN amount ELSE 0 END), 0) AS transport_expenses,
        COALESCE(SUM(CASE WHEN category='Employee Salary' THEN amount ELSE 0 END), 0) AS salary_expenses,
        COALESCE(SUM(CASE WHEN category NOT IN ('Stock Purchase','Transport','Employee Salary') THEN amount ELSE 0 END), 0) AS other_expenses
      FROM expenses WHERE expense_date = $1
    `, [date])

    // 7-day trend
    const trend = await query(`
      SELECT s.sale_date::text AS date,
        COALESCE(SUM(s.total),  0) AS sales,
        COALESCE(SUM(s.profit), 0) AS profit
      FROM sales s
      WHERE s.sale_date BETWEEN ($1::date - interval '6 days') AND $1::date
      GROUP BY s.sale_date ORDER BY s.sale_date
    `, [date])

    // Top products
    const topProducts = await query(`
      SELECT
        si.product_name,
        SUM(si.qty)      AS qty_sold,
        SUM(si.subtotal) AS revenue,
        SUM(si.profit)   AS profit
      FROM sale_items si
      JOIN sales s ON s.id = si.sale_id
      WHERE s.sale_date = $1
      GROUP BY si.product_name
      ORDER BY revenue DESC LIMIT 5
    `, [date])

    // Real-time today's sales list with items + payments
    const todaySales = await query(`
      SELECT s.*,
        json_agg(DISTINCT jsonb_build_object(
          'product_name', si.product_name, 'denomination_label', si.denomination_label,
          'sale_type', si.sale_type, 'qty', si.qty,
          'unit_price', si.unit_price, 'subtotal', si.subtotal, 'profit', si.profit
        )) FILTER (WHERE si.id IS NOT NULL) AS items,
        json_agg(DISTINCT jsonb_build_object(
          'method', sp.method, 'amount', sp.amount
        )) FILTER (WHERE sp.id IS NOT NULL) AS payments
      FROM sales s
      LEFT JOIN sale_items si ON si.sale_id = s.id
      LEFT JOIN sale_payments sp ON sp.sale_id = s.id
      WHERE s.sale_date = $1
      GROUP BY s.id ORDER BY s.created_at DESC
    `, [date])

    const prevCash = Number(prevCashRow.prev_cash)
    const cashToday = Number(payBreakdown.cash_sales)

    return NextResponse.json({
      data: {
        date,
        sales: { ...salesSummary, ...payBreakdown },
        expenses: expenseSummary,
        prev_cash: prevCash,
        available_cash: prevCash + cashToday,
        net_profit: Number(salesSummary.total_profit) - Number(expenseSummary.total_expenses),
        trend,
        top_products: topProducts,
        today_sales: todaySales,
      }
    })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { query } from '@/lib/db'

export async function GET(req: NextRequest) {
  try {
    const { searchParams } = new URL(req.url)
    const month = searchParams.get('month') || new Date().toISOString().slice(0, 7)

    const [salesSummary] = await query(`
      SELECT
        COUNT(DISTINCT s.id)           AS tx_count,
        COALESCE(SUM(s.total),  0)     AS total_sales,
        COALESCE(SUM(s.profit), 0)     AS total_profit
      FROM sales s
      WHERE TO_CHAR(s.sale_date,'YYYY-MM') = $1
    `, [month])

    const [payBreakdown] = await query(`
      SELECT
        COALESCE(SUM(CASE WHEN sp.method='cash'   THEN sp.amount ELSE 0 END), 0) AS cash_sales,
        COALESCE(SUM(CASE WHEN sp.method='mpesa'  THEN sp.amount ELSE 0 END), 0) AS mpesa_sales,
        COALESCE(SUM(CASE WHEN sp.method='kcb'    THEN sp.amount ELSE 0 END), 0) AS kcb_sales,
        COALESCE(SUM(CASE WHEN sp.method='credit' THEN sp.amount ELSE 0 END), 0) AS credit_sales
      FROM sale_payments sp
      JOIN sales s ON s.id = sp.sale_id
      WHERE TO_CHAR(s.sale_date,'YYYY-MM') = $1
    `, [month])

    const [expenseSummary] = await query(`
      SELECT COALESCE(SUM(amount), 0) AS total_expenses
      FROM expenses WHERE TO_CHAR(expense_date,'YYYY-MM') = $1
    `, [month])

    const dailyBreakdown = await query(`
      SELECT sale_date::text AS date,
        COALESCE(SUM(total),  0) AS sales,
        COALESCE(SUM(profit), 0) AS profit,
        COUNT(*) AS tx_count
      FROM sales
      WHERE TO_CHAR(sale_date,'YYYY-MM') = $1
      GROUP BY sale_date ORDER BY sale_date
    `, [month])

    const topProducts = await query(`
      SELECT si.product_name,
        SUM(si.qty)      AS qty_sold,
        SUM(si.subtotal) AS revenue,
        SUM(si.profit)   AS profit
      FROM sale_items si
      JOIN sales s ON s.id = si.sale_id
      WHERE TO_CHAR(s.sale_date,'YYYY-MM') = $1
      GROUP BY si.product_name
      ORDER BY revenue DESC LIMIT 10
    `, [month])

    const [creditSummary] = await query(`
      SELECT COUNT(*) AS count, COALESCE(SUM(total),0) AS amount
      FROM sales WHERE status='pending' AND TO_CHAR(sale_date,'YYYY-MM') = $1
    `, [month])

    return NextResponse.json({
      data: {
        month,
        sales: { ...salesSummary, ...payBreakdown },
        expenses: expenseSummary,
        net_profit: Number(salesSummary.total_profit) - Number(expenseSummary.total_expenses),
        daily_breakdown: dailyBreakdown,
        top_products: topProducts,
        credit: creditSummary
      }
    })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

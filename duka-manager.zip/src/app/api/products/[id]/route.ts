import { NextRequest, NextResponse } from 'next/server'
import { query, queryOne } from '@/lib/db'

export async function GET(_: NextRequest, { params }: { params: { id: string } }) {
  try {
    const product = await queryOne(`
      SELECT p.*,
        (SELECT json_agg(d ORDER BY d.sort_order)
         FROM product_denominations d
         WHERE d.product_id = p.id AND d.is_active = TRUE
        ) AS denominations
      FROM products p WHERE p.id=$1
    `, [params.id])
    if (!product) return NextResponse.json({ error: 'Not found' }, { status: 404 })
    return NextResponse.json({ data: product })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function PUT(req: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await req.json()
    const ex = await queryOne('SELECT * FROM products WHERE id=$1', [params.id])
    if (!ex) return NextResponse.json({ error: 'Not found' }, { status: 404 })

    const newQty = Number(body.qty ?? ex.qty)
    const diff = newQty - Number(ex.qty)

    const product = await queryOne(`
      UPDATE products SET
        name=$1, category=$2, supplier=$3, qty=$4,
        buy_price=$5, ws_price=$6, retail_price=$7,
        low_stock_threshold=$8, sell_mode=$9, base_unit=$10,
        base_qty=$11, ws_pack_qty=$12, ws_pack_label=$13,
        units_per_dozen=$12, updated_at=NOW()
      WHERE id=$14 RETURNING *
    `, [
      body.name??ex.name, body.category??ex.category, body.supplier??ex.supplier, newQty,
      body.buy_price??ex.buy_price, body.ws_price??ex.ws_price,
      body.retail_price??ex.retail_price, body.low_stock_threshold??ex.low_stock_threshold,
      body.sell_mode??ex.sell_mode, body.base_unit??ex.base_unit,
      body.base_qty??ex.base_qty, body.ws_pack_qty??ex.ws_pack_qty,
      body.ws_pack_label??ex.ws_pack_label, params.id
    ])

    if (diff !== 0)
      await query(
        `INSERT INTO stock_movements (product_id, type, qty, note) VALUES ($1,$2,$3,'Manual adjustment')`,
        [params.id, diff>0?'in':'adjustment', Math.abs(diff)]
      )

    // Update denominations if provided
    if (body.denominations?.length) {
      await query('DELETE FROM product_denominations WHERE product_id=$1', [params.id])
      for (let i = 0; i < body.denominations.length; i++) {
        const d = body.denominations[i]
        await query(
          `INSERT INTO product_denominations (product_id, label, fraction, sell_price, sort_order)
           VALUES ($1,$2,$3,$4,$5)`,
          [params.id, d.label, Number(d.fraction), Number(d.sell_price), i]
        )
      }
    }

    return NextResponse.json({ data: product })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

export async function DELETE(_: NextRequest, { params }: { params: { id: string } }) {
  try {
    await query('DELETE FROM products WHERE id=$1', [params.id])
    return NextResponse.json({ success: true })
  } catch (e: any) {
    return NextResponse.json({ error: e.message }, { status: 500 })
  }
}

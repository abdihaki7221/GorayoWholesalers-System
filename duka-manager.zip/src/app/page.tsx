'use client'
import { useEffect, useState, useCallback } from 'react'
import Link from 'next/link'
import { fmt, fmtTime, today } from '@/lib/utils'

const PAY_BADGE: Record<string, string> = {
  cash: 'badge-green', mpesa: 'badge-blue', kcb: 'badge-yellow', credit: 'badge-red'
}

export default function Dashboard() {
  const [data, setData] = useState<any>(null)
  const [loading, setLoading] = useState(true)

  const load = useCallback(() => {
    fetch(`/api/reports/daily?date=${today()}`)
      .then(r => r.json())
      .then(d => { setData(d.data); setLoading(false) })
  }, [])

  useEffect(() => {
    load()
    // Auto-refresh every 30 seconds
    const t = setInterval(load, 30000)
    return () => clearInterval(t)
  }, [load])

  if (loading) return <div className="empty-state animate-in">Loading dashboard...</div>

  const s = data?.sales || {}
  const e = data?.expenses || {}
  const todaySales: any[] = data?.today_sales || []

  return (
    <div className="animate-in">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="page-title">Dashboard</h1>
          <p className="page-sub">
            {new Date().toLocaleDateString('en-KE', { weekday:'long', year:'numeric', month:'long', day:'numeric' })}
            <span className="ml-3 text-xs text-muted">Auto-refreshes every 30s</span>
          </p>
        </div>
        <div className="flex gap-2">
          <button className="btn btn-outline btn-sm" onClick={load}>🔄 Refresh</button>
          <Link href="/pos" className="btn btn-primary">➕ New Sale</Link>
        </div>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="stat-card green">
          <div className="stat-label">Today's Sales</div>
          <div className="stat-value">{Number(s.total_sales||0).toLocaleString('en-KE',{maximumFractionDigits:0})}</div>
          <div className="stat-sub">{s.tx_count||0} transactions</div>
        </div>
        <div className="stat-card yellow">
          <div className="stat-label">Gross Profit</div>
          <div className="stat-value">{Number(s.total_profit||0).toLocaleString('en-KE',{maximumFractionDigits:0})}</div>
          <div className="stat-sub">From all sales today</div>
        </div>
        <div className="stat-card blue">
          <div className="stat-label">Cash Available</div>
          <div className="stat-value">{Number(data?.available_cash||0).toLocaleString('en-KE',{maximumFractionDigits:0})}</div>
          <div className="stat-sub">Prev + today's cash</div>
        </div>
        <div className="stat-card red">
          <div className="stat-label">Net Profit</div>
          <div className={`stat-value ${Number(data?.net_profit||0)>=0?'text-green':'text-red'}`}>
            {Number(data?.net_profit||0).toLocaleString('en-KE',{maximumFractionDigits:0})}
          </div>
          <div className="stat-sub">After expenses</div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 mb-4">
        {/* Payment breakdown */}
        <div className="duka-card">
          <div className="duka-card-title">💳 Payment Breakdown</div>
          {[
            { label:'💵 Cash',   val: s.cash_sales||0,   cls:'text-green' },
            { label:'📱 M-Pesa', val: s.mpesa_sales||0,  cls:'text-blue'  },
            { label:'🏦 KCB',    val: s.kcb_sales||0,    cls:'text-yellow' },
            { label:'📋 Credit', val: s.credit_sales||0, cls:'text-red'   },
          ].map(r => (
            <div key={r.label} className="flex justify-between py-2 border-b border-border last:border-0">
              <span className="text-sub text-sm">{r.label}</span>
              <span className={`mono font-semibold ${r.cls}`}>{fmt(r.val)}</span>
            </div>
          ))}
        </div>

        {/* Top products */}
        <div className="duka-card">
          <div className="duka-card-title">🏆 Top Products Today</div>
          {data?.top_products?.length ? (
            <div className="space-y-2">
              {data.top_products.map((p: any, i: number) => (
                <div key={i} className="flex justify-between items-center py-1 border-b border-border last:border-0">
                  <div>
                    <div className="text-sm text-white">{p.product_name}</div>
                    <div className="text-xs text-muted">Profit: <span className="text-yellow">{fmt(p.profit)}</span></div>
                  </div>
                  <span className="mono text-sm text-green">{fmt(p.revenue)}</span>
                </div>
              ))}
            </div>
          ) : <div className="empty-state py-6">No sales yet today</div>}
        </div>

        {/* Expenses */}
        <div className="duka-card">
          <div className="duka-card-title">💸 Today's Expenses</div>
          {[
            { label:'📦 Stock',     val: e.stock_expenses||0 },
            { label:'🚛 Transport', val: e.transport_expenses||0 },
            { label:'👤 Salary',    val: e.salary_expenses||0 },
            { label:'📎 Other',     val: e.other_expenses||0 },
          ].map(r => (
            <div key={r.label} className="flex justify-between py-2 border-b border-border last:border-0">
              <span className="text-sub text-sm">{r.label}</span>
              <span className="mono text-sm text-red">{fmt(r.val)}</span>
            </div>
          ))}
          <div className="flex justify-between pt-2 font-semibold">
            <span className="text-sm">Total</span>
            <span className="mono text-red">{fmt(e.total_expenses||0)}</span>
          </div>
        </div>
      </div>

      {/* Live sales feed */}
      {todaySales.length > 0 && (
        <div className="duka-card mb-4">
          <div className="duka-card-title">
            🔴 Live Sales Feed
            <span className="badge badge-green text-xs">{todaySales.length} transactions</span>
          </div>
          <div className="overflow-x-auto">
            <table className="duka-table">
              <thead>
                <tr>
                  <th>Time</th>
                  <th>Receipt</th>
                  <th>Customer</th>
                  <th>Items</th>
                  <th>Total</th>
                  <th>Profit</th>
                  <th>Payment</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {todaySales.map((s: any) => {
                  const payments: any[] = s.payments || []
                  return (
                    <tr key={s.id}>
                      <td className="text-muted">{fmtTime(s.created_at)}</td>
                      <td className="mono text-white text-xs">{s.receipt_no}</td>
                      <td>{s.customer_name}</td>
                      <td className="text-muted text-xs">
                        {(s.items||[]).filter(Boolean).map((it: any, i: number) => (
                          <div key={i}>{it.product_name} {it.denomination_label ? `(${it.denomination_label})` : ''} ×{Number(it.qty).toFixed(it.qty%1?2:0)}</div>
                        ))}
                      </td>
                      <td className="mono text-green font-semibold">{fmt(s.total)}</td>
                      <td className="mono text-yellow font-semibold">{fmt(s.profit)}</td>
                      <td>
                        {payments.filter(Boolean).map((p: any, i: number) => (
                          <div key={i} className="flex items-center gap-1 mb-0.5">
                            <span className={`badge ${PAY_BADGE[p.method]||'badge-gray'} text-xs`}>{p.method.toUpperCase()}</span>
                            <span className="mono text-xs text-muted">{fmt(p.amount)}</span>
                          </div>
                        ))}
                      </td>
                      <td>
                        <span className={`badge ${s.status==='paid'?'badge-green':'badge-red'}`}>{s.status}</span>
                      </td>
                    </tr>
                  )
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* 7-day trend */}
      {data?.trend?.length > 0 && (
        <div className="duka-card">
          <div className="duka-card-title">📈 7-Day Sales Trend</div>
          <table className="duka-table">
            <thead><tr><th>Date</th><th>Sales</th><th>Profit</th><th>Bar</th></tr></thead>
            <tbody>
              {data.trend.map((t: any) => {
                const max = Math.max(...data.trend.map((x: any) => Number(x.sales)))
                const pct = max > 0 ? (Number(t.sales)/max)*100 : 0
                return (
                  <tr key={t.date}>
                    <td>{new Date(t.date).toLocaleDateString('en-KE',{weekday:'short',day:'2-digit',month:'short'})}</td>
                    <td className="mono text-green">{fmt(t.sales)}</td>
                    <td className="mono text-yellow">{fmt(t.profit)}</td>
                    <td style={{width:180}}>
                      <div className="bg-surface2 rounded-full h-2 overflow-hidden">
                        <div className="bg-accent h-2 rounded-full" style={{width:`${pct}%`}}/>
                      </div>
                    </td>
                  </tr>
                )
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  )
}

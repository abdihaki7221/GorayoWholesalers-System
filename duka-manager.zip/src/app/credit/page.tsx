'use client'
import { useEffect, useState } from 'react'
import toast from 'react-hot-toast'
import { fmt, fmtDate } from '@/lib/utils'
import ReceiptModal from '@/components/ReceiptModal'

export default function CreditPage() {
  const [credits, setCredits] = useState<any[]>([])
  const [loading, setLoading] = useState(true)
  const [receipt, setReceipt] = useState<any>(null)

  function load() {
    setLoading(true)
    fetch('/api/sales?status=pending')
      .then(r => r.json())
      .then(d => { setCredits(d.data || []); setLoading(false) })
  }

  useEffect(() => { load() }, [])

  async function markPaid(id: number, method = 'cash') {
    try {
      const res = await fetch(`/api/sales/${id}`, {
        method: 'PATCH',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ status: 'paid', payment_method: method })
      })
      if (!res.ok) throw new Error('Failed')
      toast.success(`Marked as paid (${method})`)
      load()
    } catch { toast.error('Failed to update') }
  }

  const total = credits.reduce((a, s) => a + Number(s.total), 0)

  return (
    <div className="animate-in">
      <div className="mb-6">
        <h1 className="page-title">Credit / Debtors</h1>
        <p className="page-sub">Customers with outstanding payments</p>
      </div>

      <div className="grid grid-cols-2 lg:grid-cols-3 gap-4 mb-6">
        <div className="stat-card red">
          <div className="stat-label">Total Outstanding</div>
          <div className="stat-value">{Number(total).toLocaleString('en-KE', { minimumFractionDigits: 0 })}</div>
          <div className="stat-sub">KES owed</div>
        </div>
        <div className="stat-card yellow">
          <div className="stat-label">Credit Customers</div>
          <div className="stat-value">{credits.length}</div>
          <div className="stat-sub">pending transactions</div>
        </div>
      </div>

      <div className="duka-card">
        {loading ? (
          <div className="empty-state">Loading...</div>
        ) : credits.length === 0 ? (
          <div className="empty-state">🎉 No outstanding credit — all customers are paid up!</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="duka-table">
              <thead>
                <tr>
                  <th>Customer</th>
                  <th>Date</th>
                  <th>Receipt #</th>
                  <th>Items</th>
                  <th>Amount Owed</th>
                  <th>Actions</th>
                </tr>
              </thead>
              <tbody>
                {credits.map(s => (
                  <tr key={s.id}>
                    <td className="text-white font-medium">{s.customer_name}</td>
                    <td>{fmtDate(s.sale_date)}</td>
                    <td className="mono">{s.receipt_no}</td>
                    <td className="text-muted">{(s.items || []).filter(Boolean).length} item(s)</td>
                    <td className="mono text-red font-semibold text-base">{fmt(s.total)}</td>
                    <td>
                      <div className="flex gap-2 flex-wrap">
                        <button className="btn btn-success btn-sm" onClick={() => markPaid(s.id, 'cash')}>💵 Cash</button>
                        <button className="btn btn-outline btn-sm" onClick={() => markPaid(s.id, 'mpesa')}>📱 M-Pesa</button>
                        <button className="btn btn-outline btn-sm" onClick={() => markPaid(s.id, 'kcb')}>🏦 KCB</button>
                        <button className="btn btn-ghost btn-sm" onClick={() => setReceipt(s)}>🧾</button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {receipt && <ReceiptModal sale={receipt} onClose={() => setReceipt(null)} />}
    </div>
  )
}

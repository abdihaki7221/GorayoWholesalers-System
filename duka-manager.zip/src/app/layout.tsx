import type { Metadata } from 'next'
import { DM_Sans, DM_Mono, DM_Serif_Display } from 'next/font/google'
import './globals.css'
import Sidebar from '@/components/Sidebar'
import { Toaster } from 'react-hot-toast'

const dmSans = DM_Sans({ subsets: ['latin'], variable: '--font-sans' })
const dmMono = DM_Mono({ subsets: ['latin'], weight: ['400', '500'], variable: '--font-mono' })
const dmSerif = DM_Serif_Display({ subsets: ['latin'], weight: '400', variable: '--font-serif' })

export const metadata: Metadata = {
  title: 'Duka Manager',
  description: 'Wholesale & Retail Business Management',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body className={`${dmSans.variable} ${dmMono.variable} ${dmSerif.variable} bg-bg text-white font-sans`}>
        <Toaster position="top-right" toastOptions={{
          style: { background: '#181c27', color: '#e8eaf0', border: '1px solid #2a3047' }
        }} />
        <div className="flex min-h-screen">
          <Sidebar />
          <main className="ml-60 flex-1 p-7 min-h-screen">
            {children}
          </main>
        </div>
      </body>
    </html>
  )
}

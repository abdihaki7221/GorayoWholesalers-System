'use client'
import { useEffect, useState } from 'react'
import Link from 'next/link'
import toast from 'react-hot-toast'
import { fmt } from '@/lib/utils'

export default function StockPage() {
  const [products, setProducts] = useState<any[]>([])
  const [search, setSearch] = useState('')
  const [loading, setLoading] = useState(true)
  const [expanded, setExpanded] = useState<number | null>(null)
  const [editProduct, setEditProduct] = useState<any>(null)

  function load(q = '') {
    setLoading(true)
    fetch(`/api/products?search=${q}`)
      .then(r => r.json())
      .then(d => { setProducts(d.data || []); setLoading(false) })
  }

  useEffect(() => { load() }, [])

  async function saveEdit() {
    try {
      const res = await fetch(`/api/products/${editProduct.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(editProduct)
      })
      const data = await res.json()
      if (!res.ok) throw new Error(data.error)
      toast.success('Updated!')
      setEditProduct(null)
      load(search)
    } catch (e: any) { toast.error(e.message) }
  }

  async function del(id: number, name: string) {
    if (!confirm(`Delete "${name}"?`)) return
    await fetch(`/api/products/${id}`, { method: 'DELETE' })
    toast.success('Deleted')
    load(search)
  }

  const totalValue = products.reduce((a, p) => a + Number(p.buy_price) * Number(p.qty), 0)
  const categories = [...new Set(products.map(p => p.category))]

  return (
    <div className="animate-in">
      <div className="flex items-start justify-between mb-6">
        <div>
          <h1 className="page-title">Stock</h1>
          <p className="page-sub">{products.length} products · Inventory value: <strong className="text-accent">{fmt(totalValue)}</strong></p>
        </div>
        <Link href="/stock/add" className="btn btn-primary">➕ Add Stock</Link>
      </div>

      <div className="duka-card mb-4">
        <input className="duka-input" placeholder="🔍 Search products by name or category..."
          value={search} onChange={e => { setSearch(e.target.value); load(e.target.value) }} />
      </div>

      {loading ? <div className="empty-state">Loading...</div> : products.length === 0 ? (
        <div className="empty-state">
          No products found.<br />
          <Link href="/stock/add" className="btn btn-primary mt-4 inline-flex">➕ Add First Product</Link>
        </div>
      ) : (
        categories.map(cat => {
          const catProds = products.filter(p => p.category === cat)
          return (
            <div key={cat} className="duka-card mb-4">
              <div className="duka-card-title">{cat} <span className="badge badge-gray">{catProds.length}</span></div>
              <div className="overflow-x-auto">
                <table className="duka-table">
                  <thead>
                    <tr>
                      <th>Product</th><th>Cost/base unit</th><th>Stock</th>
                      <th>WS Price</th><th>Mode</th><th>Status</th><th>Sizes</th><th>Actions</th>
                    </tr>
                  </thead>
                  <tbody>
                    {catProds.map(p => {
                      const isOut = Number(p.qty) === 0
                      const isLow = !isOut && Number(p.qty) < Number(p.low_stock_threshold)
                      const denoms: any[] = p.denominations || []
                      const isExp = expanded === p.id
                      return (
                        <tr key={p.id}>
                          <td>
                            <div className="text-white font-medium">{p.name}</div>
                            <div className="text-xs text-muted">{p.supplier}</div>
                          </td>
                          <td className="mono">{fmt(p.buy_price)}<span className="text-muted text-xs">/{p.base_unit}</span></td>
                          <td className="mono">
                            <div>{Number(p.qty).toFixed(1)} {p.base_unit}</div>
                            {p.sell_mode !== 'denominations' && (
                              <div className="text-xs text-muted">{Math.floor(Number(p.qty)/Number(p.ws_pack_qty))} {p.ws_pack_label}</div>
                            )}
                          </td>
                          <td className="mono text-yellow">{p.sell_mode!=='denominations'?`${fmt(p.ws_price)}/${p.ws_pack_label}`:'—'}</td>
                          <td><span className={`badge ${p.sell_mode==='both'?'badge-blue':p.sell_mode==='denominations'?'badge-green':'badge-yellow'}`}>{p.sell_mode}</span></td>
                          <td><span className={`badge ${isOut?'badge-red':isLow?'badge-yellow':'badge-green'}`}>{isOut?'Out of Stock':isLow?'Low Stock':'In Stock'}</span></td>
                          <td>
                            {denoms.length > 0 ? (
                              <button className="btn btn-ghost btn-sm text-blue" onClick={() => setExpanded(isExp?null:p.id)}>
                                {isExp?'▲':'▼'} {denoms.length} sizes
                              </button>
                            ) : <span className="text-muted text-xs">—</span>}
                            {isExp && (
                              <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center p-4" onClick={() => setExpanded(null)}>
                                <div className="bg-surface border border-border rounded-xl p-6 max-w-2xl w-full" onClick={e => e.stopPropagation()}>
                                  <div className="flex justify-between mb-4">
                                    <h3 className="font-semibold text-white">{p.name} — Retail Sizes</h3>
                                    <button className="btn btn-ghost btn-sm" onClick={() => setExpanded(null)}>✕</button>
                                  </div>
                                  <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
                                    {denoms.map((d: any) => {
                                      const cost = Number(p.buy_price) * Number(d.fraction)
                                      const profit = Number(d.sell_price) - cost
                                      return (
                                        <div key={d.id} className="bg-surface2 rounded-lg p-4">
                                          <div className="text-white font-bold text-lg">{d.label}</div>
                                          <div className="text-xs text-muted mb-2">{d.fraction}× {p.base_unit}</div>
                                          <div className="text-accent mono font-bold">{fmt(d.sell_price)}</div>
                                          <div className="text-xs text-muted mt-1">Cost: <span className="text-red">{fmt(cost)}</span></div>
                                          <div className="text-xs mt-0.5">Profit: <span className={`font-bold ${profit>=0?'text-green':'text-red'}`}>{fmt(profit)}</span></div>
                                        </div>
                                      )
                                    })}
                                  </div>
                                </div>
                              </div>
                            )}
                          </td>
                          <td>
                            <div className="flex gap-2">
                              <button className="btn btn-outline btn-sm" onClick={() => setEditProduct({ ...p })}>✏️ Edit</button>
                              <button className="btn btn-ghost btn-sm text-red" onClick={() => del(p.id, p.name)}>🗑️</button>
                            </div>
                          </td>
                        </tr>
                      )
                    })}
                  </tbody>
                </table>
              </div>
            </div>
          )
        })
      )}

      {editProduct && (
        <div className="modal-overlay" onClick={e => e.target === e.currentTarget && setEditProduct(null)}>
          <div className="modal" style={{ maxWidth: 600 }}>
            <h2 className="modal-title">Edit: {editProduct.name}</h2>
            <div className="grid grid-cols-2 gap-4">
              {[
                { label:'Product Name', key:'name', type:'text', span:true },
                { label:'Supplier', key:'supplier', type:'text' },
                { label:`Quantity (${editProduct.base_unit}s)`, key:'qty', type:'number' },
                { label:'Buy Price / base unit', key:'buy_price', type:'number' },
                { label:'WS Price / pack', key:'ws_price', type:'number' },
                { label:'WS Pack Qty', key:'ws_pack_qty', type:'number' },
                { label:'WS Pack Label', key:'ws_pack_label', type:'text' },
                { label:'Low Stock Threshold', key:'low_stock_threshold', type:'number' },
              ].map(f => (
                <div key={f.key} className={(f as any).span?'col-span-2':''}>
                  <label className="duka-label">{f.label}</label>
                  <input type={f.type} className="duka-input" value={editProduct[f.key]??''}
                    onChange={e => setEditProduct({...editProduct,[f.key]:e.target.value})} />
                </div>
              ))}
            </div>
            {(editProduct.denominations||[]).length > 0 && (
              <div className="mt-5">
                <div className="duka-label mb-2">Denominations (Label | Fraction | Sell Price)</div>
                <div className="space-y-2">
                  {(editProduct.denominations||[]).map((d:any,i:number) => (
                    <div key={i} className="grid grid-cols-3 gap-2">
                      <input className="duka-input" value={d.label} onChange={e => {
                        const nd=[...editProduct.denominations]; nd[i]={...nd[i],label:e.target.value}
                        setEditProduct({...editProduct,denominations:nd})}} />
                      <input type="number" step="0.001" className="duka-input" value={d.fraction} onChange={e => {
                        const nd=[...editProduct.denominations]; nd[i]={...nd[i],fraction:e.target.value}
                        setEditProduct({...editProduct,denominations:nd})}} />
                      <input type="number" step="0.01" className="duka-input" value={d.sell_price} onChange={e => {
                        const nd=[...editProduct.denominations]; nd[i]={...nd[i],sell_price:e.target.value}
                        setEditProduct({...editProduct,denominations:nd})}} />
                    </div>
                  ))}
                </div>
              </div>
            )}
            <div className="flex justify-end gap-3 mt-6">
              <button className="btn btn-outline" onClick={() => setEditProduct(null)}>Cancel</button>
              <button className="btn btn-primary" onClick={saveEdit}>Save Changes</button>
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

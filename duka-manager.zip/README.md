# 🏪 Duka Manager — Wholesale & Retail Business System

A complete business management system built with **Next.js 14 + PostgreSQL** for wholesale and retail shops.

---

## ✅ Features

| Module | What it does |
|--------|-------------|
| **Dashboard** | Live stats: today's sales, profit, cash, credit. 7-day trend. |
| **POS / New Sale** | Add items (retail or wholesale), multiple payment methods, auto change calc, receipt printing |
| **Stock Management** | CRUD for all products, buying/wholesale/retail prices, low stock alerts |
| **Add Stock** | Record new deliveries, transport cost spreading, margin calculator |
| **Sales History** | Full transaction log, filter by date/status/customer, re-print receipts |
| **Credit / Debtors** | All unpaid sales, mark paid via Cash / M-Pesa / KCB |
| **Expenses** | Record stock, transport, salary, rent, other costs |
| **Daily Summary** | Cash position (prev day + today), P&L, payment breakdown, top products |
| **Monthly Report** | Bar charts, daily breakdown, top products, payment summary |

---

## 🚀 Quick Setup (5 minutes)

### 1. Prerequisites
- [Node.js 18+](https://nodejs.org/)
- [PostgreSQL 14+](https://www.postgresql.org/download/)

### 2. Create the database

Open **psql** (or pgAdmin) and run:
```sql
CREATE DATABASE duka_manager;
```

### 3. Install the project

```bash
# Unzip and enter the folder
cd duka-manager

# Install dependencies
npm install

# Copy environment file
cp .env.example .env.local
```

### 4. Configure your database connection

Edit `.env.local` and update the connection string:
```
DATABASE_URL=postgresql://postgres:YOUR_PASSWORD@localhost:5432/duka_manager
```

Replace `YOUR_PASSWORD` with your PostgreSQL password.

### 5. Run database migrations

```bash
npm run db:migrate
```

This creates all the tables automatically.

### 6. (Optional) Add sample data

```bash
npm run db:seed
```

This adds 5 sample products so you can test right away.

### 7. Start the system

```bash
npm run dev
```

Open your browser to **http://localhost:3000** 🎉

---

## 📖 How to Use

### Recording a Sale
1. Click **New Sale** in the sidebar
2. Select a product from the dropdown
3. Choose **Retail** (per unit) or **Wholesale** (per dozen)
4. Enter quantity and click **Add to Cart**
5. Add more items if needed
6. Select payment method: Cash / M-Pesa / KCB / Credit
7. Click **Complete Sale & Print Receipt**

### Adding New Stock
1. Click **Add Stock** → fill in product name, category, supplier
2. Enter quantity received and buying price per unit
   - *Example: If you buy Unga at 1520/dozen, enter 1520÷12 = 126.67 per unit*
3. Add transport cost (auto-spread across all units)
4. Set wholesale price (per dozen) and retail price (per unit)
5. The system shows suggested prices and margin percentages
6. Click **Save Stock** — stock purchase is auto-recorded as an expense

### Credit Sales
- When a customer can't pay now, select **Credit** as payment method
- The sale is recorded as "pending"
- Go to **Credit / Debtors** to see all outstanding amounts
- When they pay, click **Cash**, **M-Pesa**, or **KCB** to mark as paid

### Daily End-of-Day
1. Go to **Daily Summary**
2. See total sales, payment breakdown, cash position, and P&L
3. Cash position = previous day cash + today's cash sales
4. Click **Print** for a hard copy

---

## 🗄️ Database Tables

| Table | Purpose |
|-------|---------|
| `products` | All products with prices and stock levels |
| `stock_movements` | History of stock ins and outs |
| `sales` | All sale transactions / receipts |
| `sale_items` | Line items for each sale |
| `expenses` | All business expenses |
| `customers` | Customer records (optional) |
| `daily_cash` | Manual opening cash entries (optional) |

---

## 🔌 API Endpoints

| Method | Endpoint | Description |
|--------|----------|-------------|
| GET/POST | `/api/products` | List / create products |
| GET/PUT/DELETE | `/api/products/[id]` | Get / update / delete product |
| GET/POST | `/api/sales` | List / create sales |
| GET/PATCH | `/api/sales/[id]` | Get sale / mark paid |
| GET/POST | `/api/expenses` | List / create expenses |
| PUT/DELETE | `/api/expenses/[id]` | Update / delete expense |
| GET | `/api/reports/daily` | Daily summary report |
| GET | `/api/reports/monthly` | Monthly summary report |

---

## 🖨️ Receipt Printing

When you complete a sale, a receipt preview appears. Click **Print Receipt** — it opens a clean print dialog showing only the receipt. Works on any printer connected to your computer.

---

## 💡 Tips

- **Multiple staff**: Run `npm run dev` on the server computer. Other devices on the same WiFi network can access it at `http://YOUR_COMPUTER_IP:3000`
- **Backup**: Your data is in PostgreSQL. Use `pg_dump duka_manager > backup.sql` to backup
- **Restore**: Use `psql duka_manager < backup.sql` to restore

---

## 🛠️ Tech Stack

- **Frontend**: Next.js 14, React, Tailwind CSS
- **Backend**: Next.js API Routes (Node.js)
- **Database**: PostgreSQL via `pg` driver
- **Charts**: Recharts
- **Fonts**: DM Sans, DM Mono, DM Serif Display
